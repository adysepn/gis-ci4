<h1>Selamat Datang di</h1>
<h1>Website SIG Teknik UNSOED</h1>
<br>
<h3>Disini Terdapat Peta Online yang menunjukkan Lokasi Teknik Unsoed</h3>
<h4>Fitur-Fitur yang ada disini, diantaranya yaitu:</h4>
<ul>
    <li>Jenis Peta yang Berbeda</li>
    <li>Marker Tiap Gedung</li>
    <li>Rute Jalan Ke Gedung</li>
    <li>Area Wifi Tiap Gedung</li>
</ul>